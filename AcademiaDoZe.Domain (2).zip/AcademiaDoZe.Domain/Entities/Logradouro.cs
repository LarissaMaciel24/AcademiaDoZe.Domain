﻿using System;
using System.Collections.Generic;
using System.Text;

// Larissa Maciel

namespace AcademiaDoZe.Domain.Entities;

public class Logradouro
{
    public string Pais { get; private set; }
    public string Estado { get; private set; }
    public string Cidade { get; private set; }
    public string Bairro { get; private set; }
    public string Nome { get; private set; }

    public Logradouro(
        string pais,
        string estado,
        string cidade,
        string bairro,
        string nome)
    {
        Pais = pais;
        Estado = estado;
        Cidade = cidade;
        Bairro = bairro;
        Nome = nome;
    }
}