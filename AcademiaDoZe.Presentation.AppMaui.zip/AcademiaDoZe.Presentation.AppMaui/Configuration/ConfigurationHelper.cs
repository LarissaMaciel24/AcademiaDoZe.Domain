﻿using AcademiaDoZe.Application.DependencyInjection;
using AcademiaDoZe.Application.Enums;
using AcademiaDoZe.Application.Mappings;
using Microsoft.Extensions.DependencyInjection;

namespace AcademiaDoZe.Presentation.AppMaui.Configuration;

public static class ConfigurationHelper
{
    public static void ConfigureServices(IServiceCollection services)
    {
        // Tipo de banco usado pelo app
        var databaseType = AppDatabaseType.MySql;

        // Troque a senha pela senha do SEU MySQL
        const string dbServer = "localhost";
        const string dbDatabase = "db_academia_do_ze";
        const string dbUser = "root";
        const string dbPassword = "root";

        var connectionString =
            $"Server={dbServer};Database={dbDatabase};User Id={dbUser};Password={dbPassword};" +
            "Connection Timeout=5;Default Command Timeout=30;";

        // Fábrica de repositórios
        services.AddSingleton(new RepositoryConfig
        {
            ConnectionString = connectionString,
            DatabaseType = databaseType.ToInfrastructure()
        });

        // Serviços da camada de aplicação
        services.AddApplicationServices();
    }
}